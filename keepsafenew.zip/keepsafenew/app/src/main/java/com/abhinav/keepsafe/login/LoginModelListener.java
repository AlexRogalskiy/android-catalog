package com.abhinav.keepsafe.login;

import com.abhinav.keepsafe.base.BaseModelListener;

/**
 * Created by abhinav.sharma on 09/10/17.
 */

interface LoginModelListener extends BaseModelListener {

}
