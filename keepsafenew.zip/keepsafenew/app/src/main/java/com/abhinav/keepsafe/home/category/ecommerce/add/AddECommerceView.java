package com.abhinav.keepsafe.home.category.ecommerce.add;

import com.abhinav.keepsafe.base.IBaseView;

/**
 * Created by abhinav.sharma on 14/10/17.
 */

interface AddECommerceView extends IBaseView{
    void popFragment();
}
