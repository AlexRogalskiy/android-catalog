package com.abhinav.keepsafe.home.category.bank.edit;

import com.abhinav.keepsafe.base.BaseModel;
import com.abhinav.keepsafe.base.BaseModelListener;

/**
 * Created by abhinav.sharma on 20/10/17.
 */

class EditBankModel extends BaseModel<BaseModelListener>{

    public EditBankModel(BaseModelListener listener) {
        super(listener);
    }
}
