package com.abhinav.keepsafe.home.category.bank.show;

import com.abhinav.keepsafe.base.BaseModel;
import com.abhinav.keepsafe.base.BaseModelListener;

/**
 * Created by abhinav.sharma on 24/11/17.
 */

class ShowBankModel extends BaseModel<BaseModelListener> {
    public ShowBankModel(BaseModelListener listener) {
        super(listener);
    }
}
