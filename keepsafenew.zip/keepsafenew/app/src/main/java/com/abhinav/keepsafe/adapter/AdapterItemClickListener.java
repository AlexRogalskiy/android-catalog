package com.abhinav.keepsafe.adapter;

/**
 * Created by abhinav.sharma on 15/10/17.
 */

public interface AdapterItemClickListener {
    void onItemClick(int position);
}
