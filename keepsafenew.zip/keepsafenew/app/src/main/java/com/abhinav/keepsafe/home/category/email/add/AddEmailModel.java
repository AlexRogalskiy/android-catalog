package com.abhinav.keepsafe.home.category.email.add;

import com.abhinav.keepsafe.base.BaseModel;
import com.abhinav.keepsafe.base.BaseModelListener;

/**
 * Created by abhinav.sharma on 13/10/17.
 */

class AddEmailModel extends BaseModel<BaseModelListener>{

    public AddEmailModel(BaseModelListener listener) {
        super(listener);
    }
}
