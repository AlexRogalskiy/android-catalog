package com.abhinav.keepsafe.home.category.ecommerce.add;

import com.abhinav.keepsafe.base.BaseModel;
import com.abhinav.keepsafe.base.BaseModelListener;

/**
 * Created by abhinav.sharma on 14/10/17.
 */

class AddECommerceModel extends BaseModel<BaseModelListener>{

    public AddECommerceModel(BaseModelListener listener) {
        super(listener);
    }
}
