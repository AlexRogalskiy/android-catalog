package com.abhinav.keepsafe.login;

import com.abhinav.keepsafe.base.BaseModel;

/**
 * Created by abhinav.sharma on 09/10/17.
 */

public class LoginModel extends BaseModel<LoginModelListener> {

    public LoginModel(LoginModelListener listener) {
        super(listener);
    }
}
