package com.abhinav.keepsafe.home.category;

import com.abhinav.keepsafe.base.BaseModelListener;

/**
 * Created by abhinav.sharma on 11/10/17.
 */

interface CategoryModelListener extends BaseModelListener {
}
