package com.abhinav.keepsafe.home.category;

import com.abhinav.keepsafe.base.BaseModel;

/**
 * Created by abhinav.sharma on 11/10/17.
 */

class CategoryModel extends BaseModel<CategoryModelListener> {

    public CategoryModel(CategoryModelListener listener) {
        super(listener);
    }




}
