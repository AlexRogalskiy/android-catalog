package com.abhinav.keepsafe.home.category.email.add;

import com.abhinav.keepsafe.base.IBaseView;

/**
 * Created by abhinav.sharma on 13/10/17.
 */

public interface AddEmailView extends IBaseView {

    void onSaveClicked();
    void popFragment();
}
