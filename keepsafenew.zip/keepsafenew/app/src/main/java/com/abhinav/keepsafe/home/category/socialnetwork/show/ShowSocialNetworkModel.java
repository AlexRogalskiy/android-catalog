package com.abhinav.keepsafe.home.category.socialnetwork.show;

import com.abhinav.keepsafe.base.BaseModel;
import com.abhinav.keepsafe.base.BaseModelListener;

/**
 * Created by abhinav.sharma on 25/11/17.
 */

class ShowSocialNetworkModel extends BaseModel<BaseModelListener> {

    public ShowSocialNetworkModel(BaseModelListener listener) {
        super(listener);
    }
}
