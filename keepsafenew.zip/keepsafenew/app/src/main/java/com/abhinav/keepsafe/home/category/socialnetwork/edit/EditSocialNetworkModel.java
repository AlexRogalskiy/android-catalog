package com.abhinav.keepsafe.home.category.socialnetwork.edit;

import com.abhinav.keepsafe.base.BaseModel;
import com.abhinav.keepsafe.base.BaseModelListener;

/**
 * Created by abhinav.sharma on 22/10/17.
 */

class EditSocialNetworkModel extends BaseModel<BaseModelListener> {

    public EditSocialNetworkModel(BaseModelListener listener) {
        super(listener);
    }
}
