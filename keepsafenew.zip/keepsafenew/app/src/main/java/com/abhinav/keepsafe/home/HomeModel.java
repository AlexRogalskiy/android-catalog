package com.abhinav.keepsafe.home;

import com.abhinav.keepsafe.base.BaseModel;

/**
 * Created by abhinav.sharma on 11/10/17.
 */

class HomeModel extends BaseModel<HomeModelListener>{

    public HomeModel(HomeModelListener listener) {
        super(listener);
    }
}
