package com.abhinav.keepsafe.home.category.socialnetwork.add;

import com.abhinav.keepsafe.base.BaseModel;
import com.abhinav.keepsafe.base.BaseModelListener;

/**
 * Created by abhinav.sharma on 14/10/17.
 */

class AddSocialNetworkModel extends BaseModel<BaseModelListener>{

    public AddSocialNetworkModel(BaseModelListener listener) {
        super(listener);
    }
}
