package com.abhinav.keepsafe.home.category.bank.add;

import com.abhinav.keepsafe.base.IBaseView;

/**
 * Created by abhinav.sharma on 12/10/17.
 */

public interface AddBankView extends IBaseView {

    void onSaveClicked();
    void popFragment();
}
