package com.abhinav.keepsafe.home.category.ecommerce.edit;

import com.abhinav.keepsafe.base.BaseModel;
import com.abhinav.keepsafe.base.BaseModelListener;

/**
 * Created by abhinav.sharma on 23/10/17.
 */

class EditECommerceModel extends BaseModel<BaseModelListener>{

    public EditECommerceModel(BaseModelListener listener) {
        super(listener);
    }
}
