package com.abhinav.keepsafe.home.category.email.show;

import com.abhinav.keepsafe.base.BaseModel;
import com.abhinav.keepsafe.base.BaseModelListener;

/**
 * Created by abhinav.sharma on 25/11/17.
 */

class ShowEMailModel extends BaseModel<BaseModelListener> {
    public ShowEMailModel(BaseModelListener listener) {
        super(listener);
    }
}
