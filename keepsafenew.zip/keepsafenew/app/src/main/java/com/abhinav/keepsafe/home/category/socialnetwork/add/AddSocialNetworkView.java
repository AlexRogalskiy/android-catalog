package com.abhinav.keepsafe.home.category.socialnetwork.add;

import com.abhinav.keepsafe.base.IBaseView;

/**
 * Created by abhinav.sharma on 13/10/17.
 */

interface AddSocialNetworkView extends IBaseView {
    void popFragment();
}
