package com.abhinav.keepsafe.home.category.bank.add;

import com.abhinav.keepsafe.base.BaseModel;
import com.abhinav.keepsafe.base.BaseModelListener;

/**
 * Created by abhinav.sharma on 12/10/17.
 */

class AddBankModel extends BaseModel<BaseModelListener>{

    public AddBankModel(BaseModelListener listener) {
        super(listener);
    }
}
