package com.abhinav.keepsafe.home.category.email.edit;

import com.abhinav.keepsafe.base.BaseModel;
import com.abhinav.keepsafe.base.BaseModelListener;

/**
 * Created by abhinav.sharma on 21/10/17.
 */

class EditEmailModel extends BaseModel<BaseModelListener>{

    public EditEmailModel(BaseModelListener listener) {
        super(listener);
    }
}
