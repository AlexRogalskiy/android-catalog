package com.abhinav.keepsafe.home;

import com.abhinav.keepsafe.base.BaseModelListener;

/**
 * Created by abhinav.sharma on 11/10/17.
 */

interface HomeModelListener extends BaseModelListener{
}
