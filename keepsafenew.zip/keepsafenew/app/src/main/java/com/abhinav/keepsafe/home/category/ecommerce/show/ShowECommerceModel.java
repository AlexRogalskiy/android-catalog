package com.abhinav.keepsafe.home.category.ecommerce.show;

import com.abhinav.keepsafe.base.BaseModel;
import com.abhinav.keepsafe.base.BaseModelListener;

/**
 * Created by abhinav.sharma on 25/11/17.
 */

class ShowECommerceModel extends BaseModel<BaseModelListener> {

    public ShowECommerceModel(BaseModelListener listener) {
        super(listener);
    }
}
